import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TechnologiesComponent } from './technologies/technologies.component';

const routes: Routes = [
  {path:'basics',component:AngularBasicsComponent},
  {path:'technologies',component:TechnologiesComponent},
  {path:'pipes',component:AngularPipesComponent},
  {path:'**',redirectTo:'basics'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
