import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender'
})
export class GenderPipe implements PipeTransform {

  constructor() {
    console.log("GenderPipes Created....");
  }
  transform(value: any, args?: any): any {
    console.log("GenderPipe transform method....");
    switch(value){
      case 1:return 'Male';
      case 2:return 'Female';
      case 3:return 'Not Disclose';
    }  
  }

}
